public interface OrderItem {
    String getDescription();

    double getCost();
}